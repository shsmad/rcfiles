Guide to using filemagic
========================

.. include:: guide_content
