#! /usr/bin/python

import PyMetrics.PyMetrics as pm
import sys

pm.main ()
sys.exit (0)
